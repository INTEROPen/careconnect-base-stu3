###Introduction
Introductory guidance on myExtension
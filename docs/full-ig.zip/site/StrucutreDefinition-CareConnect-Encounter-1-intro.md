## Clinical Encounters

In the UK the Core Encounter resource is focused around clinical ecounters. 

It does not cover admit, discharge and transfers (ADT), this may lead to confusion for existing developers approaching Care Connect.
 
### Care Connect CodeSystems

Code Systems used in this implementation guide.

{% include table-codesystems.xhtml %}
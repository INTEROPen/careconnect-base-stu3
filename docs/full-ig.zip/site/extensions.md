### Care Connect Extensions

{% include table-extensions.xhtml %}
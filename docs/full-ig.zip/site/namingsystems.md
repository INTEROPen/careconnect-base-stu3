### Care Connect NamingSystems

See also [System Identifiers](https://github.com/HL7-UK/System-Identifiers)

{% include table-namingsystems.xhtml %}